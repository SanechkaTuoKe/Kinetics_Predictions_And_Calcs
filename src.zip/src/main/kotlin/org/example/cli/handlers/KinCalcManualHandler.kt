package org.example.cli.handlers

import org.example.domain.Properties
import org.example.service.CalculationService
import org.example.service.PythonRunner


class KinCalcManualHandler : BaseHandler {

    override fun handle(
        params: List<String>,
        calculationService: CalculationService,
        commandList: Collection<BaseHandler>
    ): Boolean {

        if (params.size < 2) {
            println("Usage: kin-calc-manual <times> <percents>")
            println("Example: kin-calc-manual 15,30,45 10.5,25.3,40.1")
            return true
        }

        val times = params[0].split(",").mapNotNull { it.toDoubleOrNull() }
        val percents = params[1].split(",").mapNotNull { it.toDoubleOrNull() }

        if (times.size != percents.size) {
            println("Error: Number of time points (${times.size}) != number of percentages (${percents.size})")
            return true
        }

        val result = PythonRunner.runKineticsModel(times, percents)

        if (result != null) {
            val (model, k, t50, r2) = result
            println("=== KINETICS RESULTS ===")
            println("Best Model   : ${model.uppercase()} Order")
            println("R²           : $r2")
            if (model != "none") {
                println("Rate Const (k): $k")
                println("Half-Life (t½): $t50 min")
            }
            println("")
        } else {
            println("Error: Calculation failed")
        }

        return true
    }

    override fun help(): String = "kin-calc-manual <times> <percents> - Calculate kinetics manually"
}