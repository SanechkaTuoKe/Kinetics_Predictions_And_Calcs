package org.example.cli.handlers

import org.example.service.CalculationService

class RelShowHandler: BaseHandler {
    override fun handle(
        params: List<String>,
        calculationService: CalculationService,
        commandList: Collection<BaseHandler>
    ): Boolean {
        TODO("Not yet implemented")
    }

    override fun help(): String = "RelShow for see needed releases"
}