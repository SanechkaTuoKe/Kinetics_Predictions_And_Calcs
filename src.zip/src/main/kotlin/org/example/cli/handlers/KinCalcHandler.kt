package org.example.cli.handlers

import org.example.domain.Properties
import org.example.service.CalculationService
import org.example.service.PythonRunner


class KinCalcHandler : BaseHandler {

    override fun handle(
        params: List<String>,
        calculationService: CalculationService,
        commandList: Collection<BaseHandler>
    ): Boolean {

        val experiment = calculationService.getLastExperiment()

        if (experiment == null) {
            println("Error: No experiment data found.")
            println("First use 'rel-add' to calculate release data, then run 'kin-calc'")
            println("\nAlternatively, use: kin-calc-manual <times> <percents>")
            return true
        }

        println("Using experiment '${experiment.id}' (${experiment.subject})")
        println("Time points: ${experiment.times}")
        println("Release %: ${experiment.releasePercents}")
        println()

        val result = PythonRunner.runKineticsModel(
            experiment.times,
            experiment.releasePercents
        )

        if (result != null) {
            val (model, k, t50, r2) = result

            println("=== KINETICS RESULTS ===")
            println("Experiment   : ${experiment.id}")
            println("Subject      : ${experiment.subject}")
            println("Best Model   : ${model.uppercase()} Order")
            println("R²           : $r2")

            if (model != "none") {
                println("Rate Const (k): $k")
                println("Half-Life (t½): $t50 min")
            } else {
                println("No suitable model found (R² < 0.95)")
            }
            println("")
        } else {
            println("Error: Failed to calculate kinetics")
        }

        return true
    }

    override fun help(): String = "kin-calc - Calculate kinetics for last experiment (use after rel-add)"
}