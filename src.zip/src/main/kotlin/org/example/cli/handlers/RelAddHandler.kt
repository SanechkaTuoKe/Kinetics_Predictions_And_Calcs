package org.example.cli.handlers

import org.example.domain.Properties
import org.example.service.CalculationService
import org.example.service.PythonRunner

class RelAddHandler : BaseHandler {

    override fun handle(
        params: List<String>,
        calculationService: CalculationService,
        commandList: Collection<BaseHandler>
    ): Boolean {

        if (params.size < 4) {
            println("Error: Not enough parameters.")
            println("Usage: rel-add <ID> <SUBJECT> <ads_data> <release_data>")
            println("Example: rel-exp exp1 CLX 0.187,0.118,0.105 0.541,0.404,0.303")
            return true
        }

        val expId = params[0]
        val subjectName = params[1].uppercase()

        val subject = when (subjectName) {
            "CLX" -> Properties.CLX
            "FLC" -> Properties.FLC
            else -> {
                println("Error: Unknown subject '$subjectName'. Use CLX or FLC.")
                return true
            }
        }

        val adsData = params[2].split(",").mapNotNull { it.toDoubleOrNull() }
        val relData = params[3].split(",").mapNotNull { it.toDoubleOrNull() }

        val defaultTimes = listOf(15.0, 30.0, 45.0, 60.0, 90.0, 120.0, 180.0)
        val times = if (params.size > 4) {
            params[4].split(",").mapNotNull { it.toDoubleOrNull() }
        } else {
            defaultTimes
        }

        if (adsData.isEmpty() || relData.isEmpty()) {
            println("Error: Invalid data format.")
            return true
        }

        println("Calculating release for experiment '$expId' ($subject)...")

        val result = PythonRunner.runReleaseCalculation(subject, adsData, relData)

        if (result != null) {
            val (c0, adsPercents, relPercents) = result

            println("RESULTS for $expId")
            println("C0: $c0 mol/L")
            println("Adsorption %: $adsPercents")
            println("Release %: $relPercents")
            println("Time points: $times")

            calculationService.saveExperiment(
                id = expId,
                subject = subject,
                times = times,
                releasePercents = relPercents,
                c0 = c0,
                adsorptionPercents = adsPercents
            )

            println("\n💡 Use 'kin-calc' to calculate kinetics for this experiment")
        } else {
            println("Error: Calculation failed")
        }

        return true
    }

    override fun help(): String = "rel-add <ID> <SUBJECT> <ads_data> <release_data> [times] - Calculate and save release data"
}